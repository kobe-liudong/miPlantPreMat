The training and the testing datasets are included in this folder.

mirPlantMat19.txt: All the plant miRNAs published in miRbase 19

mirPlantMat20.txt: All the plant miRNAs published in miRbase 20

mirPlantPre19.txt: All the plant pre-miRNAs published in miRbase 19

mirPlantPre20.txt: All the plant pre-miRNAs published in miRbase 20

mirPlantPre19_single.txt: All the plant miRNAs and their pre-miRNAs in one stem-loop structure of miRbase 19

mirPlantPre20_single.txt: All the plant miRNAs and their pre-miRNAs in one stem-loop structure of miRbase 20

negData.txt: Pseudo pre-miRNAs we selected from cDNAs