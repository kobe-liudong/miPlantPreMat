  
  #@arr = (7,12,14,17,18,24,27); 

 # for($i=53; $i <= 64; $i++)
  #{
     #$x = $arr[$i];
   #  print("\n".$i);
    # system("perl microPred.pl x-.$i.fasta");
  #}

  print("\n 83-1");
  system("perl microPred.pl x-.83-1.fasta");
  print("\n 83-2");
  system("perl microPred.pl x-.83-2.fasta");
  print("\n 84-1");
  system("perl microPred.pl x-.84-1.fasta");
  print("\n 84-2");
  system("perl microPred.pl x-.84-2.fasta");
  print("\n 85-1");
  system("perl microPred.pl x-.85-1.fasta");
  print("\n 85-2");
  system("perl microPred.pl x-.85-2.fasta");